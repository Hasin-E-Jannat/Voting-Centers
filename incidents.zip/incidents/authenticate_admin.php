<?php
// ১. সেশন শুরু করা
session_start();

// ২. এরর রিপোর্টিং চালু করা (ডিবাগিংয়ের জন্য)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ৩. কনফিগারেশন ফাইল লোড করা
$config = require 'config.php';

// ৪. পোস্ট ডেটা গ্রহণ করা
$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

// ৫. ইউজারনেম এবং পাসওয়ার্ড চেক করা
// এখানে config.php থেকে 'admin_username' এবং 'admin_password' ব্যবহার করা হয়েছে
if ($username === $config['admin_username'] && $password === $config['admin_password']) {
    
    // সেশন সেট করা
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['username'] = $username;
    
    // সফল হলে অ্যাডমিন প্যানেলে পাঠানো
    header('Location: admin_panel.php');
    exit;
    
} else {
    // ব্যর্থ হলে পুনরায় লগইন পেজে পাঠানো
    header('Location: admin_login.html?error=invalid');
    exit;
}
?>