<?php
// ===================================
// DEBUGGING: REMOVE THESE LINES WHEN LIVE
// ===================================
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// ===================================

// --- Configuration ---
$incident_data_file = 'incident_reports.json';
$upload_dir = 'uploads/'; // <--- Correct variable name

// Ensure the uploads directory exists
if (!is_dir($upload_dir)) {
    // Corrected variable name: $upload_dir
    mkdir($upload_dir, 0777, true);
}
// Removed the erroneous is_dir check on $incident_data_file


// 1. Data Collection (Collect ALL fields safely)
$title = $_POST['title'] ?? '';
$description = $_POST['description'] ?? '';
$center_id = $_POST['center_id'] ?? '';
$latitude = $_POST['latitude'] ?? 'N/A';
$longitude = $_POST['longitude'] ?? 'N/A';
$report_time = date('Y-m-d H:i:s');
$uploaded_file_path = 'N/A';


// 2. Handle File Upload (This assumes the form field name is 'incident_proof')
if (isset($_FILES['incident_proof']) && $_FILES['incident_proof']['error'] === UPLOAD_ERR_OK) {
    // Directory is already checked and created above

    $file_info = pathinfo($_FILES['incident_proof']['name']);
    $new_file_name = uniqid('proof_', true) . '.' . ($file_info['extension'] ?? 'tmp');
    $target_file = $upload_dir . $new_file_name;

    if (move_uploaded_file($_FILES['incident_proof']['tmp_name'], $target_file)) {
        $uploaded_file_path = $target_file;
    } 
}


// 3. Load Existing Data
$existing_data = [];
if (file_exists($incident_data_file)) {
    $json_content = file_get_contents($incident_data_file);
    $existing_data = json_decode($json_content, true);

    if (!is_array($existing_data)) {
        error_log("Incident JSON file corrupted. Resetting data array.");
        $existing_data = []; 
    }
}


// 4. Determine the new Incident ID (Simulate AUTO_INCREMENT)
$new_id = 1;
if (!empty($existing_data)) {
    $last_key = array_key_last($existing_data);
    if ($last_key !== null) {
        // Ensure the last ID is treated as a number
        $new_id = (int)$existing_data[$last_key]['id'] + 1;
    }
}


// 5. Create New Incident Record
$new_incident = [
    'id' => $new_id,
    'report_time' => $report_time,
    'title' => $title,
    'description' => $description,
    'center_id' => $center_id,
    'proof_path' => $uploaded_file_path,
    'latitude' => $latitude,
    'longitude' => $longitude,
];


// 6. Append New Record and Save
$existing_data[] = $new_incident;
$updated_json_content = json_encode($existing_data, JSON_PRETTY_PRINT);

// IMPORTANT: Use LOCK_EX for atomic write operation
if (file_put_contents($incident_data_file, $updated_json_content, LOCK_EX) === false) {
    // If the write fails (usually permission issue), log and exit gracefully
    error_log("CRITICAL ERROR: Failed to write to incident_reports.json. Check file permissions (666 or 777).");
    header('Location: incident_form.html?status=write_error');
    exit;
}


// 7. SMS Notification (If implemented, it would go here)
// ...

// 8. Success Redirect
header('Location: success.html');
exit;
?>