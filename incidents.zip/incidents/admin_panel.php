<?php foreach ($incidents as $incident): 
    $center_id = $incident['center_id'] ?? null;
    $center_info = $centers[$center_id] ?? null;
    $center_name = $center_info['name'] ?? 'Unknown';
?>
<tr>
    <td data-label="ID"><?= htmlspecialchars($incident['id']) ?></td>
    <td data-label="Center">
        <strong><?= htmlspecialchars($center_name) ?></strong>
        <div class="mobile-only">
            <a href="geo:<?= $center_info['lat'] ?>,<?= $center_info['lng'] ?>" class="btn-nav">Open in Maps</a>
        </div>
    </td>
    <td data-label="Proof">
        <?php if (!empty($incident['proof_path'])): ?>
            <a href="<?= htmlspecialchars($incident['proof_path']) ?>" target="_blank">
                <img src="<?= htmlspecialchars($incident['proof_path']) ?>" style="width:50px; border-radius:4px;">
            </a>
        <?php endif; ?>
    </td>
    <td data-label="Status">
        <span class="badge badge-pending">New</span>
    </td>
</tr>
<?php endforeach; ?>