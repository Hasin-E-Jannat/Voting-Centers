<?php
// config.php
return [
    'uploads_dir' => __DIR__ . '/uploads',
    'incidents_file' => __DIR__ . '/incident_reports.json',
    'centers_file' => __DIR__ . '/centers_info.json',
    'contacts_file' => __DIR__ . '/contacts.json',
    
    // Security: Use password_hash() to generate this hash for 'secure123'
    'admin_username' => 'admin',
    'admin_password_hash' => 'secure123', 

    'category_map' => [
        'violence' => 'সহিংসতা',
        'fraud' => 'জালিয়াতি',
        'obstruction' => 'বাধা প্রদান'
    ]
];