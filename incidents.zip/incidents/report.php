<?php
// report.php
// Receives multipart/form-data: centerName, category, time, lat, lng, reporterContact, photo (file)
// Returns JSON with officers list (no SMS)

$config = require __DIR__ . '/config.php';

// ensure dirs exist
if (!is_dir($config->UPLOAD_DIR)) mkdir($config->UPLOAD_DIR, 0777, true);
if (!is_dir($config->INCIDENT_DIR)) mkdir($config->INCIDENT_DIR, 0777, true);

// helper: send JSON response
function jsonOut($arr, $code = 200) {
    header('Content-Type: application/json');
    http_response_code($code);
    echo json_encode($arr, JSON_UNESCAPED_UNICODE);
    exit;
}

// input validation
$centerName = isset($_POST['centerName']) ? trim($_POST['centerName']) : null;
$category = isset($_POST['category']) ? trim($_POST['category']) : null;
$time = isset($_POST['time']) ? trim($_POST['time']) : date(DATE_ATOM);
$lat = isset($_POST['lat']) ? trim($_POST['lat']) : null;
$lng = isset($_POST['lng']) ? trim($_POST['lng']) : null;
$reporterContact = isset($_POST['reporterContact']) ? trim($_POST['reporterContact']) : null;

if (!$centerName || !$category) {
    jsonOut(['ok' => false, 'error' => 'centerName and category are required'], 400);
}

// handle file upload (optional)
$photoPath = null;
if (!empty($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
    $f = $_FILES['photo'];
    $ext = pathinfo($f['name'], PATHINFO_EXTENSION);
    $safe = preg_replace('/[^a-zA-Z0-9_\-\.]/', '_', pathinfo($f['name'], PATHINFO_FILENAME));
    $filename = time() . '-' . bin2hex(random_bytes(4)) . ($ext ? '.' . $ext : '');
    $dest = rtrim($config->UPLOAD_DIR, '/') . '/' . $filename;
    if (!move_uploaded_file($f['tmp_name'], $dest)) {
        jsonOut(['ok' => false, 'error' => 'Failed to move uploaded file'], 500);
    }
    $photoPath = 'uploads/' . $filename;
}

// load contacts
$contactsJson = @file_get_contents($config->CONTACT_FILE);
if ($contactsJson === false) {
    jsonOut(['ok' => false, 'error' => 'contacts file missing'], 500);
}
$contacts = json_decode($contactsJson, true);
$offices = [];
if (is_array($contacts) && count($contacts) > 0 && isset($contacts[0]['offices'])) {
    $offices = $contacts[0]['offices'];
}

// map category to bangla
$catMap = $config->CATEGORY_MAP;
$banglaCat = isset($catMap[$category]) ? $catMap[$category] : null;

// select officers
$matched = [];
if ($banglaCat !== null) {
    foreach ($offices as $o) {
        if (isset($o['category']) && $o['category'] === $banglaCat) $matched[] = $o;
    }
}
if (count($matched) === 0) {
    // fallback: priority 1 officers
    foreach ($offices as $o) {
        if (isset($o['priority']) && intval($o['priority']) === 1) $matched[] = $o;
    }
}

// build incident
$incident = [
    'id' => 'inc_' . time() . '_' . bin2hex(random_bytes(3)),
    'created_at' => date(DATE_ATOM),
    'centerName' => $centerName,
    'category' => $category,
    'time' => $time,
    'lat' => $lat ?: null,
    'lng' => $lng ?: null,
    'reporterContact' => $reporterContact ?: null,
    'photo' => $photoPath,
    'officers' => []
];

foreach ($matched as $m) {
    $incident['officers'][] = [
        'id' => $m['id'] ?? null,
        'type' => $m['type'] ?? null,
        'designation' => $m['designation'] ?? null,
        'priority' => $m['priority'] ?? null,
        'mobile' => $m['mobile'] ?? null,
        'category' => $m['category'] ?? null
    ];
}

// save incident file
$fname = $incident['id'] . '.json';
$full = rtrim($config->INCIDENT_DIR, '/') . '/' . $fname;
if (file_put_contents($full, json_encode($incident, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) === false) {
    jsonOut(['ok' => false, 'error' => 'Failed to save incident file'], 500);
}

// success
jsonOut(['ok' => true, 'message' => 'Incident recorded (no SMS).', 'incident_file' => $fname, 'officers' => $incident['officers']]);
