<?php
session_start();

// 1. AUTHENTICATION CHECK
// Ensures only logged-in Upazila users can access this form.
if (!isset($_SESSION['user_logged_in']) || !isset($_SESSION['assigned_upazila'])) {
    header('Location: index.html');
    exit;
}

$userUpazila = $_SESSION['assigned_upazila'];
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Correction - <?php echo htmlspecialchars($userUpazila); ?></title>
    <style>
        :root {
            --primary-blue: #1a73e8;
            --success-green: #28a745;
            --bg-gray: #f8f9fa;
            --border-color: #dee2e6;
        }

        body { 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            background-color: var(--bg-gray); 
            margin: 0; 
            padding: 20px; 
            color: #333;
        }

        .container { 
            max-width: 650px; 
            margin: auto; 
            background: white; 
            padding: 40px; 
            border-radius: 12px; 
            box-shadow: 0 4px 20px rgba(0,0,0,0.08); 
        }

        .header-meta { 
            display: flex; 
            justify-content: space-between; 
            align-items: center; 
            margin-bottom: 25px; 
            border-bottom: 2px solid var(--bg-gray); 
            padding-bottom: 15px; 
        }

        .user-badge {
            background: #e8f0fe;
            color: var(--primary-blue);
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
        }

        h1 { 
            font-size: 24px; 
            color: var(--primary-blue); 
            margin-top: 0;
            text-align: center;
        }

        label { 
            font-weight: 600; 
            display: block; 
            margin-top: 20px; 
            margin-bottom: 8px;
            color: #555; 
        }

        select, textarea { 
            width: 100%; 
            padding: 12px; 
            border: 1px solid var(--border-color); 
            border-radius: 8px; 
            box-sizing: border-box; 
            font-size: 15px;
            transition: border-color 0.2s;
        }

        select:focus, textarea:focus {
            border-color: var(--primary-blue);
            outline: none;
            box-shadow: 0 0 0 3px rgba(26,115,232,0.1);
        }

        button { 
            width: 100%; 
            padding: 16px; 
            background-color: var(--success-green); 
            color: white; 
            border: none; 
            border-radius: 8px; 
            cursor: pointer; 
            font-size: 16px; 
            font-weight: bold; 
            margin-top: 30px;
            transition: background 0.2s;
        }

        button:hover { background-color: #218838; }

        .footer-links {
            margin-top: 25px;
            text-align: center;
            font-size: 14px;
        }

        .footer-links a {
            color: var(--primary-blue);
            text-decoration: none;
            margin: 0 10px;
        }

        .logout-btn { color: #dc3545 !important; }

        .success-msg {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
        }
        .doict-footer {
    position: fixed;
    bottom: 0;
    left: 0;
    width: 100%;
    background: rgba(255, 255, 255, 0.95); /* Clean white glass effect */
    backdrop-filter: blur(10px);
    border-top: 1px solid #e2e8f0; /* Soft border divider */
    padding: 8px 20px;
    z-index: 2000;
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: 0 -2px 10px rgba(0,0,0,0.05);
}

.doict-footer a {
    display: flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
    color: #1b1c1d; /* Professional slate grey */
    transition: color 0.3s ease;
}

.doict-footer a:hover {
    color: #1fa5ae; /* Matches your deep teal highlight */
}

.doict-footer img {
    height: 24px;
    width: auto;
    opacity: 0.8;
    transition: all 0.3s ease;
}

.doict-footer a:hover img {
    filter: grayscale(0); /* Colors return on hover */
    opacity: 1;
}

.doict-footer span {
    font-family: 'Anuphan', sans-serif; /* Your ultra-clear font */
    font-size: 13px;
    font-weight: 500;
    letter-spacing: 0.3px;
}

/* On Mobile: Ensure it doesn't cover content */
@media (max-width: 768px) {
    .doict-footer {
        padding: 10px;
    }
    .doict-footer span {
        font-size: 11px;
    }
}
    </style>
</head>
<body>

    <div class="container">
        <div class="header-meta">
            <span class="user-badge">Upazila: <?php echo htmlspecialchars($userUpazila); ?></span>
            <span>User: <strong><?php echo htmlspecialchars($username); ?></strong></span>
        </div>

        <?php if (isset($_GET['success'])): ?>
            <div class="success-msg">✅ Correction Request Submitted Successfully!</div>
        <?php endif; ?>

        <h1>কেন্দ্রের তথ্য</h1>
        
        <form action="process_correction.php" method="POST">
            
            <label for="center-dropdown">কেন্দ্র বাছাই করুন</label>
            <select name="center_id" id="center-dropdown" required>
                <option value="">--কেন্দ্রের তালিকা-- <?php echo htmlspecialchars($userUpazila); ?> --</option>
            </select>

            <label for="field-dropdown">সংশোধনের জন্য তথ্য ফিল্ড বাছাই করুন</label>
            <select name="field" id="field-dropdown" required>
                <option value="">-- তথ্য ফিল্ড --</option>
            </select>

            <label for="correction">হালনাগাদ তথ্য দিন</label>
            <textarea name="correction" id="correction" rows="5" placeholder="হালনাগাদ তথ্য দিন..." required></textarea>

            <button type="submit"> সাবমিট</button>
        </form>

        <div class="footer-links">
            <a href="user_history.php">পূর্ববর্তী রেকর্ড দেখুন</a>
            <span>|</span>
            <a href="logout.php" class="logout-btn">লগ আউট</a>
        </div>
    </div>
      <footer class="doict-footer">
  <a href="http://doict.ishurdi.pabna.gov.bd/bn/site/officer_list/%E0%A6%AE%E0%A7%8B%E0%A6%B8%E0%A6%BE%E0%A6%83-%E0%A6%B9%E0%A6%BE%E0%A6%B8%E0%A6%BF%E0%A6%A8%E0%A7%87-%E0%A6%9C%E0%A6%BE%E0%A6%A8%E0%A7%8D%E0%A6%A8%E0%A6%BE%E0%A6%A4" target="_blank" rel="noopener">
    <img src="doict-logo.png" alt="DoICT Logo">
  <span><b>Hasin-E-Jannat, DoICT Ishwardi © 2026</b></span>
  </a>
</footer>

    <script>
        // Ensure PHP variable is properly passed to JS
        const myUpazila = <?php echo json_encode($userUpazila); ?>;

        fetch('centers_info.json')
            .then(response => {
                if (!response.ok) throw new Error("HTTP error " + response.status);
                return response.json();
            })
            .then(data => {
                const centerDD = document.getElementById('center-dropdown');
                const fieldDD = document.getElementById('field-dropdown');
                
                // 1. Filter centers (Checks for both 'upazila' or 'Upazila' keys)
                const myCenters = data.filter(c => (c.upazila === myUpazila || c.Upazila === myUpazila));

                if (myCenters.length === 0) {
                    centerDD.innerHTML = '<option value="">No centers found for ' + myUpazila + '</option>';
                    return;
                }

                // 2. Populate Centers
                centerDD.innerHTML = '<option value="">-- কেন্দ্র বাছাই করুন --</option>';
                myCenters.forEach(c => {
                    let opt = document.createElement('option');
                    opt.value = c.id;
                    opt.textContent = `${c.id} - ${c.name}`; 
                    centerDD.appendChild(opt);
                });

                // 3. Populate Fields
                const allowedFields = {
                    "name": "কেন্দ্রের নাম",
                    "total": "মোট ভোটার সংখ্যা",
                    "male": "পুরুষ ভোটার",
                    "female": "মহিলা ভোটার",
                    "lat": "Latitude (GPS)",
                    "lng": "Longitude (GPS)",
                    "booth_permanent": "স্থায়ী বুথের সংখ্যা",
                    "booth_temp": "অস্থায়ী বুথের সংখ্যা",
                    "area": "এলাকা/অঞ্চল"
                };

                fieldDD.innerHTML = '<option value="">-- তথ্য ফিল্ড বাছাই করুন --</option>';
                Object.keys(allowedFields).forEach(key => {
                    let opt = document.createElement('option');
                    opt.value = key;
                    opt.textContent = allowedFields[key];
                    fieldDD.appendChild(opt);
                });
            })
            .catch(error => {
                console.error('Error:', error);
                document.getElementById('center-dropdown').innerHTML = '<option value="">Error loading data. Check console.</option>';
            });
    </script>
</body>
</html>