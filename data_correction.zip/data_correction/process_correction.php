<?php
session_start();
if (!isset($_SESSION['user_logged_in'])) exit;

$file = 'corrections.json';
$data = json_decode(file_get_contents($file), true) ?? [];

$new_req = [
    'id' => uniqid('req_'),
    'user' => $_SESSION['username'],
    'center_id' => $_POST['center_id'], // Captured from form
    'field' => $_POST['field'],
    'correction' => $_POST['correction'],
    'status' => 'pending', // Default status for new submissions
    'date' => date('Y-m-d H:i:s')
];

$data[] = $new_req;
file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

header('Location: correction_form.php?success=1');
exit;
?>