<?php
session_start();

// Retrieve form data
$type = $_POST['type'] ?? '';
$user = trim($_POST['username'] ?? '');
$pass = trim($_POST['password'] ?? '');

// Credential Configuration
$creds = [
    'admin' => ['u' => 'admin', 'p' => 'secure123', 'redirect' => 'admin_panel.php'],
    'users' => [
        ['u' => 'ishwardi_user',   'p' => 'ish123',  'upazila' => 'ঈশ্বরদী',   'upazila_en' => 'Ishwardi',   'district_en' => 'Pabna'],
        ['u' => 'pabna_sadar',     'p' => 'pab123',  'upazila' => 'পাবনা সদর', 'upazila_en' => 'Pabna Sadar', 'district_en' => 'Pabna'],
        ['u' => 'atgharia_user',   'p' => 'atg123',  'upazila' => 'আটঘরিয়া',  'upazila_en' => 'Atgharia',    'district_en' => 'Pabna'],
        ['u' => 'bera_user',       'p' => 'ber123',  'upazila' => 'বেড়া',     'upazila_en' => 'Bera',        'district_en' => 'Pabna'],
        ['u' => 'bhangura_user',   'p' => 'bha123',  'upazila' => 'ভাঙ্গুড়া',  'upazila_en' => 'Bhangura',    'district_en' => 'Pabna'],
        ['u' => 'chatmohar_user',  'p' => 'cha123',  'upazila' => 'চাটমোহর',   'upazila_en' => 'Chatmohar',   'district_en' => 'Pabna'],
        ['u' => 'faridpur_user',   'p' => 'far123',  'upazila' => 'ফরিদপুর',   'upazila_en' => 'Faridpur',    'district_en' => 'Pabna'],
        ['u' => 'santhia_user',    'p' => 'san123',  'upazila' => 'সাঁথিয়া',   'upazila_en' => 'Santhia',     'district_en' => 'Pabna'],
        ['u' => 'sujanagar_user',  'p' => 'suj123',  'upazila' => 'সুজানগর',   'upazila_en' => 'Sujanagar',   'district_en' => 'Pabna']
    ]
];

// Admin Login Check
if ($type === 'admin' && $user === $creds['admin']['u'] && $pass === $creds['admin']['p']) {
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['username'] = 'Admin';
    header("Location: admin_panel.php");
    exit;
} 

// Upazila User Login Check
foreach ($creds['users'] as $u_account) {
    if ($user === $u_account['u'] && $pass === $u_account['p']) {
        $_SESSION['user_logged_in'] = true;
        $_SESSION['username'] = $user;
        
        // Storing localized data in Session
        $_SESSION['assigned_upazila'] = $u_account['upazila']; 
        $_SESSION['upazila_en'] = $u_account['upazila_en']; 
        $_SESSION['district_en'] = $u_account['district_en']; 
        
        header("Location: correction_form.php");
        exit;
    }
}

// If no match is found, redirect back with error
header("Location: index.html?error=invalid");
exit;