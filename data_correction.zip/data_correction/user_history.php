<?php
session_start();
// Security: Check if user is logged in
if (!isset($_SESSION['user_logged_in'])) { 
    header('Location: index.html'); 
    exit; 
}

$file = 'corrections.json';
// Added check to ensure file exists to prevent errors
$all_reqs = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
$all_reqs = $all_reqs ?? [];

// Load center names
$centers_raw = file_exists('centers_info.json') ? json_decode(file_get_contents('centers_info.json'), true) : [];
$centers = [];
if ($centers_raw) {
    foreach($centers_raw as $c) { 
        $centers[$c['id']] = $c['name']; 
    }
}

// STRICT FILTERING: Only show requests where 'user' matches the session
$username = $_SESSION['username'];
$user_reqs = array_filter($all_reqs, function($r) use ($username) {
    return isset($r['user']) && $r['user'] === $username;
});
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Correction History</title>
    <style>
        body { font-family: 'Segoe UI', Arial, sans-serif; background: #f0f2f5; margin: 0; padding: 20px; padding-bottom: 80px; }
        .container { max-width: 900px; margin: auto; background: white; padding: 20px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        
        .header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 2px solid #f0f2f5; padding-bottom: 15px; }
        h1 { color: #11614d; font-size: 1.5rem; margin: 0; }
        
        .nav-links a { text-decoration: none; font-size: 14px; font-weight: bold; padding: 8px 12px; border-radius: 6px; }
        .btn-back { color: #17a38e; background: #e8f6f4; margin-right: 10px; }
        .btn-logout { color: #dc3545; background: #fff1f0; }

        /* Table Styles for Desktop */
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th { text-align: left; background: #f8f9fa; color: #666; padding: 12px; font-size: 14px; }
        td { padding: 15px 12px; border-bottom: 1px solid #eee; font-size: 14px; }

        /* Status Badges */
        .status { padding: 5px 10px; border-radius: 20px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
        .status-pending { background: #fff3cd; color: #856404; }
        .status-done { background: #d4edda; color: #155724; }

        /* --- Mobile Responsive Card Layout --- */
        @media (max-width: 600px) {
            table { display: none; } /* Hide table on mobile */
            
            .mobile-card { 
                background: #fff; 
                border: 1px solid #eee; 
                border-radius: 8px; 
                padding: 15px; 
                margin-bottom: 15px; 
                display: block;
            }
            .card-row { display: flex; justify-content: space-between; margin-bottom: 8px; }
            .label { color: #888; font-size: 12px; font-weight: bold; }
            .value { font-size: 14px; color: #333; }
        }

        /* Footer Styles */
        .doict-footer { position: fixed; bottom: 0; left: 0; width: 100%; background: white; border-top: 1px solid #e2e8f0; padding: 12px; display: flex; justify-content: center; align-items: center; z-index: 1000; }
        .doict-footer a { display: flex; align-items: center; gap: 8px; text-decoration: none; color: #1b1c1d; font-size: 12px; }
        .doict-footer img { height: 20px; }
    </style>
</head>
<body>

<div class="container">
    <div class="header-flex">
        <h1>আমার সংশোধন তালিকা</h1>
        <div class="nav-links">
            <a href="correction_form.php" class="btn-back">নতুন রিকোয়েস্ট</a>
            <a href="logout.php" class="btn-logout">লগ আউট</a>
        </div>
    </div>

    <p style="font-size: 14px; color: #666;">ইউজার: <strong><?php echo htmlspecialchars($username); ?></strong></p>

    <?php if (empty($user_reqs)): ?>
        <div style="text-align:center; padding: 40px; color: #888;">
            আপনার কোনো পূর্ববর্তী রিকোয়েস্ট পাওয়া যায়নি।
        </div>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>তারিখ</th>
                    <th>সেন্টারের নাম</th>
                    <th>সংশোধনের বিষয়</th>
                    <th>অবস্থা</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach (array_reverse($user_reqs) as $r): ?>
                <tr>
                    <td><?php echo date('d M, Y', strtotime($r['date'])); ?></td>
                    <td><?php echo htmlspecialchars($centers[$r['center_id']] ?? 'Unknown'); ?></td>
                    <td><?php echo htmlspecialchars($r['field']); ?></td>
                    <td>
                        <span class="status status-<?php echo strtolower($r['status']); ?>">
                            <?php echo htmlspecialchars($r['status']); ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div class="mobile-list" style="display: none;">
            <?php foreach (array_reverse($user_reqs) as $r): ?>
            <div class="mobile-card">
                <div class="card-row">
                    <span class="label">তারিখ</span>
                    <span class="value"><?php echo date('d M, Y', strtotime($r['date'])); ?></span>
                </div>
                <div class="card-row">
                    <span class="label">সেন্টার</span>
                    <span class="value"><?php echo htmlspecialchars($centers[$r['center_id']] ?? 'Unknown'); ?></span>
                </div>
                <div class="card-row">
                    <span class="label">বিষয়</span>
                    <span class="value"><?php echo htmlspecialchars($r['field']); ?></span>
                </div>
                <div class="card-row" style="margin-top: 10px; border-top: 1px solid #f9f9f9; padding-top: 10px;">
                    <span class="label">অবস্থা</span>
                    <span class="status status-<?php echo strtolower($r['status']); ?>">
                        <?php echo htmlspecialchars($r['status']); ?>
                    </span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <script>
            // Show mobile list if screen is small
            if (window.innerWidth <= 600) {
                document.querySelector('.mobile-list').style.display = 'block';
            }
        </script>
    <?php endif; ?>
</div>

<footer class="doict-footer">
    <a href="http://doict.ishurdi.pabna.gov.bd/bn/site/officer_list/%E0%A6%AE%E0%A7%8B%E0%A6%B8%E0%A6%BE%E0%A6%83-%E0%A6%B9%E0%A6%BE%E0%A6%B8%E0%A6%BF%E0%A6%A8%E0%A7%87-%E0%A6%9C%E0%A6%BE%E0%A6%A8%E0%A7%8D%E0%A6%A8%E0%A6%BE%E0%A6%A4" target="_blank">
        <img src="doict-logo.png" alt="Logo">
        <span><b>Hasin-E-Jannat, DoICT Ishwardi © 2026</b></span>
    </a>
</footer>

</body>
</html>