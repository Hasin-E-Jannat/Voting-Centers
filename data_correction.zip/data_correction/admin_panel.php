<?php
session_start();
// Security check for admin session
if (!isset($_SESSION['admin_logged_in'])) { header('Location: admin_login.html'); exit; }

$file = 'corrections.json';
$reqs = json_decode(file_get_contents($file), true) ?? [];

// Load center names for the table
$centers_raw = json_decode(file_get_contents('centers_info.json'), true);
$centers = [];
foreach($centers_raw as $c) { $centers[$c['id']] = $c['name']; }

// Update status to 'done'
if (isset($_POST['mark_done'])) {
    foreach ($reqs as &$r) {
        if ($r['id'] === $_POST['id']) { $r['status'] = 'done'; }
    }
    file_put_contents($file, json_encode($reqs, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    header("Location: admin_panel.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Management</title>
    <style>
        body { font-family: sans-serif; padding: 20px; background: #f8f9fa; }
        table { width: 100%; border-collapse: collapse; background: white; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        th, td { border: 1px solid #dee2e6; padding: 12px; text-align: left; }
        th { background: #e9ecef; }
        .status-pending { color: #856404; background: #fff3cd; padding: 4px 8px; border-radius: 4px; font-weight: bold; }
        .status-done { color: #155724; background: #d4edda; padding: 4px 8px; border-radius: 4px; font-weight: bold; }
        .btn-done { background: #28a745; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Data Correction Management</h1>
    <table>
        <thead>
            <tr>
                <th>Date</th>
                <th>Center Name</th>
                <th>Field</th>
                <th>Suggested Correction</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach (array_reverse($reqs) as $r): ?>
            <tr>
                <td><?= $r['date'] ?></td>
                <td><?= htmlspecialchars($centers[$r['center_id']] ?? 'Unknown ID') ?></td>
                <td><?= htmlspecialchars($r['field']) ?></td>
                <td><?= nl2br(htmlspecialchars($r['correction'])) ?></td>
                <td><span class="status-<?= $r['status'] ?>"><?= strtoupper($r['status']) ?></span></td>
                <td>
                    <?php if ($r['status'] === 'pending'): ?>
                    <form method="POST">
                        <input type="hidden" name="id" value="<?= $r['id'] ?>">
                        <button type="submit" name="mark_done" class="btn-done">Mark as Done</button>
                    </form>
                    <?php else: ?>
                        ✅ Complete
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>